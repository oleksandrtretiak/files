﻿using System;
using Xamarin.Forms;

namespace Issue13258
{
	public partial class MainPage : ContentPage
	{
		public MainPage()
		{
			InitializeComponent();
		}

		void Push_Modal(object sender, EventArgs e)
		{
			Navigation.PushModalAsync(new NavigationPage(new ModalPage())
			{
				BackgroundColor = Color.Red
			});
		}

		protected override void OnAppearing()
		{
			base.OnAppearing();
		}
	}
}
