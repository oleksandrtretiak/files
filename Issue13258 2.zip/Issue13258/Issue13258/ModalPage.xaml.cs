﻿using System;
using Xamarin.Forms;

namespace Issue13258
{
	public partial class ModalPage : ContentPage
	{
		public ModalPage()
		{
			InitializeComponent();
		}

		void Pop_Modal(object sender, EventArgs e)
		{
			Navigation.PopModalAsync();
		}

		protected override void OnAppearing()
		{
			base.OnAppearing();
		}
	}
}
